import CategoryTable from "./api/CategoryTable";
import CategoryForm from "./Crud/CategoryForm";
 
 
function App() {
  return (
    <div>
      <h1>Category CRUD</h1>
      <CategoryForm />
 <CategoryTable />
    </div>
  );
}

export default App;