import React, { useEffect, useState } from "react";
import { Helmet } from "react-helmet";

function MyPage() {
  const [item, setItem] = useState(null);

  useEffect(() => {
    fetch("http://localhost/react-api-main/src/api/list.php")
      .then((res) => res.json())
      .then((data) => {
        if (data.length > 0) {
          setItem(data[0]);
        }
      })
      .catch((err) => console.error(err));
  }, []);

  return (
    <>
      <Helmet>
        <title>{item?.name || "Loading..."}</title>
        <meta
          name="description"
          content={item?.name || "Default description"}
        />
      </Helmet>

      <h1>{item?.name}</h1>
      <p>Slug: {item?.slug}</p>
      <img
        src={`YOUR_IMAGE_PATH/${item?.image}`}
        alt={item?.name}
        width="200"
      />
    </>
  );
}

export default MyPage;