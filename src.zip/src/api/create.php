<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

?>
<?php

include 'db.php';

$name = trim($_POST['name']);
$name = preg_replace('/\s+/', ' ', $name);

$slug = strtolower($name);
$slug = preg_replace('/\s+/', '-', $slug);

$imageName = '';

if(isset($_FILES['image']))
{
    $imageName = time().'_'.$_FILES['image']['name'];

    move_uploaded_file(
        $_FILES['image']['tmp_name'],
        'uploads/'.$imageName
    );
}

$sql = "INSERT INTO categories(name,slug,image)
VALUES('$name','$slug','$imageName')";

if($conn->query($sql))
{
    echo json_encode([
        "status" => true,
        "message" => "Created Successfully"
    ]);
}