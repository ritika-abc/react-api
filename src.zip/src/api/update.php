<?php

include 'db.php';

$id = $_POST['id'];

$name = trim($_POST['name']);
$name = preg_replace('/\s+/', ' ', $name);

$slug = strtolower($name);
$slug = preg_replace('/\s+/', '-', $slug);

$sql = "UPDATE categories
SET name='$name',
slug='$slug'
WHERE id='$id'";

$conn->query($sql);

echo json_encode([
    "status" => true
]);