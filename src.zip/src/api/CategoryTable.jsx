import React, { useEffect, useState } from "react";

function CategoryTable() {
  const [data, setData] = useState([]);

useEffect(() => {
  fetch("http://localhost/react-api-main/src/api/list.php")
    .then((res) => res.json())
    .then((result) => {
      console.log("API result:", result);
      setData(result);
    })
    .catch((err) => console.error("Fetch error:", err));
}, []);
  return (
    <table border="1" cellPadding="10" width="100%">
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Slug</th>
       
          <th>Created At</th>
        </tr>
      </thead>
      <tbody>
        {data.map((item) => (
          <tr key={item.id}>
            <td>{item.id}</td>
            <td>{item.name}</td>
            <td>{item.slug}</td>
            
            <td>{item.created_at}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

export default CategoryTable;