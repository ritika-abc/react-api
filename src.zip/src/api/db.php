<?php

$conn = new mysqli(
    "localhost",
    "root",
    "",
    "react_backend"
);

if ($conn->connect_error) {
    die("Connection Failed");
}