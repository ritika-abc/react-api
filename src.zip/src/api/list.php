<?php
 

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// your code below...
include 'db.php';

$result = $conn->query(
    "SELECT * FROM categories ORDER BY id DESC"
);

$data = [];

while($row = $result->fetch_assoc())
{
    $data[] = $row;
}

echo json_encode($data);