import CategoryForm from "./Crud/CategoryForm";

function App() {
  return (
    <div>
      <h1>Category CRUD</h1>
      <CategoryForm />
    </div>
  );
}

export default App;