import { useState } from "react";
import axios from "axios";

function CategoryForm() {
  const [name, setName] = useState("");
  const [image, setImage] = useState(null);

  const createSlug = (text) => {
    return text
      .trim()
      .replace(/\s+/g, " ")
      .toLowerCase()
      .replace(/\s/g, "-");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();

    formData.append(
      "name",
      name.trim().replace(/\s+/g, " ")
    );

    formData.append(
      "slug",
      createSlug(name)
    );

    formData.append("image", image);

    try {
      const response = await axios.post(
        "http://localhost/react-project/src/api/create.php",
        formData,
        {
          headers: {
            "Content-Type": "multipart/form-data",
          },
        }
      );

      console.log(response.data);

      setName("");
      setImage(null);

      alert("Category Added");
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <div>
        <label>Name</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>

      <br />

      <div>
        <label>Image</label>
        <input
          type="file"
          onChange={(e) => setImage(e.target.files[0])}
        />
      </div>

      <br />

      <button type="submit">
        Save
      </button>
    </form>
  );
}

export default CategoryForm;